package com.UST.FlightServices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
