package com.UST.employeeDocker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDockerApplicationTests {

	@Test
	void contextLoads() {
	}

}
